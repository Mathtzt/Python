from .BaseDoc import BaseDoc
from .CPF import CPF
from .CNPJ import CNPJ
from .CNH import CNH
from .CNS import CNS
from .PIS import PIS
from .TituloEleitoral import TituloEleitoral
from .generic import validate_docs
